package com.example.newwmad

class ItemModel(itemId: String, iName: String, phoneNo: String, pAddress: String, foodNames: String) {
    var itemId : String? = null
    var iName : String? = null
    var phoneNo : String? = null
    var pAddress : String? = null
    var foodNames : String? = null
}