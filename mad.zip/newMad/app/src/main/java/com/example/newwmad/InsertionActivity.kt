package com.example.newwmad

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class InsertionActivity : AppCompatActivity() {
    private lateinit var dFood: EditText
    private lateinit var eydetails: EditText
    private lateinit var pname: EditText
    private lateinit var pNo: EditText
    private lateinit var address: EditText
    private lateinit var fname: EditText
    private lateinit var add: Button

    private lateinit var dbRef: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_insertion2)

        dFood = findViewById(R.id.dFood)
        eydetails = findViewById(R.id.eydetails)
        pname = findViewById(R.id.pname)
        pNo = findViewById(R.id.pNo)
        address = findViewById(R.id.address)
        fname = findViewById(R.id.fname)
        add = findViewById(R.id.add)

        dbRef = FirebaseDatabase.getInstance().getReference("Items")

        add.setOnClickListener {
            saveItemsData()
        }


    }
    private fun saveItemsData(){
        //getting values
        val iName = pname.text.toString()
        val phoneNo = pNo.text.toString()
        val pAddress = address.text.toString()
        val foodNames = fname.text.toString()

        if (iName.isEmpty()){
            pname.error = "Please enter name"
        }
        if (phoneNo.isEmpty()){
            pNo.error = "Please enter phone no"
        }
        if (pAddress.isEmpty()){
            address.error = "Please enter address"
        }
        if (foodNames.isEmpty()){
            fname.error = "Please enter food names"
        }
        val itemId = dbRef.push().key!!
        val item = ItemModel(itemId,iName,phoneNo,pAddress,foodNames)
        dbRef.child(itemId).setValue(item)
            .addOnCompleteListener {
                Toast.makeText(this,  "Data Inserted Successfully",Toast.LENGTH_LONG).show()
                pname.text.clear()
                pNo.text.clear()
                address.text.clear()
                fname.text.clear()

            }.addOnFailureListener { err ->
                Toast.makeText(this,  "Error ${err.message}",Toast.LENGTH_LONG).show()

            }







    }
}